import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'Application2';
  rating = 8;
  posts = [
    {
      title: 'Lara Leones',
      subtitle: '@thewallart',
      image: 'assets/img11.png',
      img:'assets/img6.png',
      content: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      like: '9.8k',
      comment: '8.6k',
      share: '7.2k'
    },
    {
      title: 'Thomas J',
      subtitle: '@thecustomcreater',
      image: 'assets/img10.png',
      img:'assets/img9.png',
      content: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      like: '9.8k',
      comment: '8.6k',
      share: '7.2k'
    }
  ];

  articles = [
    { img: 'assets/img3.png', 
      img2: 'assets/img12.png',
      title: 'Thomos Edward',
      description: '@thewildwithyou'
     },
    { img: 'assets/img5.png', 
      img2: 'assets/img13.png',
      title: 'Chris Doe',
      description: '@thewildwithyou'
     },
    { img: 'assets/img7.png', 
      img2: 'assets/img15.png',
      title: 'Emilie Jones',
      description: '@thewildwithyou'
     },
    { img: 'assets/img8.png', 
      img2: 'assets/img14.png',
      title: 'Jessica Williams',
      description: '@thewildwithyou'
     }
  ];

  products = [
    {
      title: 'Modern Wall Decor Framed Painting',
      price: 199.99,
      rating: 4,
      image: 'assets/img1.png'
    },
    {
      title: 'Abstract Art Piece',
      price: 149.99,
      rating: 5,
      image: 'assets/img2.png'
    },
    {
      title: 'Colorful Artwork',
      price: 89.99,
      rating: 5,
      image: 'assets/img4.png'
    }
  ];

  constructor() { }

  ngOnInit(): void { }

  getStars(rating: number): boolean[] {
    return Array.from({ length: 5 }, (_, index) => index < rating);
  }

}
